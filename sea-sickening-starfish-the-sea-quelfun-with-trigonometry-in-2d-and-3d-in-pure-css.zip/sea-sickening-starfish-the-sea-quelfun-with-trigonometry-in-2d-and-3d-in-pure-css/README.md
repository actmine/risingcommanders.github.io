# Sea-Sickening Starfish: The Sea-quel - fun with trigonometry in 2D and 3D in pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/MackFitz/pen/QWZpyMa](https://codepen.io/MackFitz/pen/QWZpyMa).

Glow-in-the-dark starfish created with CSS trigs. Despite the impression, they aren't actually spinning. What's happening is they are actually undulating along a cosine wave in a sort of polar coordinate system: the dots aren't aligned in a row, but instead each is rotated ever so slightly and then pushed away from the center to form a closed loop. ALSO, only the inner one is 2D - the outer one is undulating in the Z axis, the dots ebbing and flowing, nearer and father away from the viewer.